MapFinding3: bajo ningun concepto el nodo destino o inicial puede ser 15 o 16.Son nodos de teleport y dan problemas.
	     Al ser los ultimos nodos de la lista, se soluciona haciento el aleatorio = lista->getTamanyo()-2;


